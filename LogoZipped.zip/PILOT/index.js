let btn = document.querySelector(".btn");
let list = document.querySelector(".list");
let listContainer = document.querySelector(".listcontainer")
btn.addEventListener("click",()=>{
  list.classList.toggle("listDrop");
  listContainer.classList.add("dropDownContainer");
})