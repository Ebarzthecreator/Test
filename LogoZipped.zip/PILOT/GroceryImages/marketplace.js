let products = [
    {
        img:"./Onions.png",
        name:"onion",
        price:"N1200",
        available:"Available",
        add:"pepper"
    },
    {
        img:"./KAle.png",
        name:"Kale",
        price:"N1200",
        available:"Available",
        add:"Kale"
    },
    {
        img:"./min.png",
        name:"Min",
        price:"N1200",
        available:"Available",
        add:"Min"
    },
    {
        img:"./Product Image Cabbage.png",
        name:"Cabbage",
        price:"N1200",
        available:"Available",
        add:"Cabbage"
    },
    {
        img:"./lettuce.png",
        name:"lettuce",
        price:"N1200",
        available:"Available",
        add:"lettuce"
    },
    {
        img:"./peas.png",
        name:"peas",
        price:"N1200",
        available:"Available",
        add:"peas"
    },
    {
        img:"./Product Image Carrot.png",
        name:"Pepper",
        price:"N1200",
        available:"Available",
        add:"Carrot"
    },
    {
        img:"./pepper.png",
        name:"onion",
        price:"N1200",
        available:"Available",
        add:"Add to cart"
    },
]

let container = document.getElementById("container");
let displayItems = products.map((object)=>{
    let img = object.img;
    let name = object.name;
    let price = object.price;
    let available = object.available;
    let add = object.add;

    return`
<div class="gridcontainer">
    <div class="container">
        <div class="imgcont">
                <img src="${img}" alt="">
        </div>
            <div class="price">
                <span>${name}</span>
                <span>${price}</span>
            </div>
        <div class="cart">
            <span >${available}</span>
            <span class="select"><button class="carts" id="cart">${add}</button></span>   
        </div>        
    </div>
</div>
    `
}).join("")
container.innerHTML = displayItems;

let btn = document.querySelectorAll(".carts");
btn.forEach((btn)=>{
    btn.addEventListener("click",(e)=>{
        let selected = e.target;
        console.log(`${selected.textContent}`)
    })
})





