let aileContainer = document.getElementById("aileContainer");
let items = [
    {    pic:"./groceries.jpg", 
         itemName : "Groceries"
    },
   
    {    pic:"./electronics.jpg", 
         itemName : "Electronics"
    },
   
    {    pic:"./toiletries.jpg", 
         itemName : "Toiletries"
    },
   
    {    pic:"./snacks.jpg", 
         itemName : "Snacks"
    },
   
    {    pic:"./fabric.jpg", 
         itemName : "Fabrics"
    },
    {    pic:"./shoes.jpg", 
         itemName : "Shoes"
    },
    {    pic:"./acessories.jpg", 
         itemName : "Accessories"
    },
    {    pic:"./perfumes.jpg", 
         itemName : "Perfumes"
    },
    {    pic:"./cosmetics.jpg", 
         itemName : "Cosmetics"
    },
    {    pic:"./furniture.jpg", 
         itemName : "Furniture",
    },
    {    pic:"./fashion.jpg", 
         itemName : "Fashion"
    },
    {    pic:"./book.jpg", 
         itemName : "Book Shelf"
    },
]

let display = items.map((obj)=>{
    let pic = obj.pic
    let itemName = obj.itemName 
    return `
    <div class="grid>
          <div class="img">
               <img src="${pic}" alt="" >
               <a class="anchor" href ="${itemName}.html"> <h3 class="name">${itemName}</h3></a>
           </div>
    </div>
    `
}).join("")
aileContainer.innerHTML = display;

let dropBtn = document.querySelector("#dropBtn");
let dropdownContainer = document.querySelector(".dropdownContainer");
dropBtn.addEventListener("click",()=>{
     console.log("clicked");
     dropdownContainer.classList.toggle("show");
})