let groceryContainer = document.querySelector(".groceriesContainer");
let price
let items = [
    {
        item :"Onions",
        price:1000,
        Img:"./GroceryImages/Onions.png",
        tag:"Onions"
    },
    {
        item :"Cabbage",
        price:800,
        Img:"./GroceryImages/Cabbage.png",
        tag:"Cabbage"
    },
    {
        item :"Kale",
        price:500,
        tag:"Kale",
        Img:"./GroceryImages/KAle.png",
    },
    {
        item :"Pepper",
        price:640,
        tag:"Pepper",
        Img:"./GroceryImages/Pepper.png",
    },
    {
        item :"Min",
        price:1000,
        tag:"Min",
        Img:"./GroceryImages/min.png",
    },
    {
        item :"Peas",
        price:400,
        tag:"Peas",
        Img:"./GroceryImages/peas.png",
    },
    {
        item :"Cucumber",
        price:1400,
        tag:"Cucumber",
        Img:"./GroceryImages/Cucumber.png",
    },
    {
        item :"Green Beans",
        tag:"Green Beans",
        price:1030,
        Img:"./GroceryImages/Green beans.png",
    },
    {
        item :"Calery",
        price:1300,
        tag:"Calery",
        Img:"./GroceryImages/Celery.png",
    },
    {
        item :"Bell pepper",
        tag:"Bell pepper",
        price:300,
        Img:"./GroceryImages/Bell pepper.png",
    },
    {
        item :"Carrot",
        tag:"Carrot",
        price:1000,
        Img:"./GroceryImages/product image carrot.png",
    },
    {
        item :"Tomatoes",
        price:500,
        tag:"Tomatoes",
        Img:"./GroceryImages/Tomatoes.png",
    }
]
// this portion is the part for populating grocery item;
let itemsDisplay =items.map((grocery)=>{
 let img = grocery.Img;
  price = grocery.price;
 let item = grocery.item;
 let tag = grocery.tag;

 return `
    <div class = "groceryContainer"> 
     <div class = "imageContainer"> 
            <img src ="${img}" alt="">
            <h3>${item}</h3>
        </div>
        <span class ="price">N${price}</span>
        <input type="number">
        <button data-Price =${price} id="${tag}" class = "groceryBtn">ADD</button>
    </div>
 `
}).join("")
let counter = document.querySelector(".counter");
groceryContainer.innerHTML = itemsDisplay;
let groceryBtn = document.querySelectorAll(".groceryBtn");
let imageContainer = document.getElementById("imageContainer");
let cartItem = document.getElementById("cartItems");
let quantity = document.querySelector(".priceAndQuantity");
let counterIndex = 0;
let sumTotal = []
let initial = 0;
function displayBtn(){
    groceryBtn.forEach((groceryBtn)=>{
        groceryBtn.addEventListener("click",()=>{
            let check = groceryBtn.id
             let inputVal = groceryBtn.previousElementSibling.value;
           let cartQuantity = groceryBtn.dataset.price;
           let totalPrice = inputVal * cartQuantity;
           let showDiv = document.createElement("div");
           showDiv.classList.add("flex");
           let firstDiv = document.createElement("div")
           let secondDiv = document.createElement("div")
           firstDiv.append(check);
           firstDiv.style.marginLeft = "1em";
           firstDiv.style.fontWeight = "bold"
           secondDiv.style.fontWeight = "bold"
           secondDiv.style.marginRight = "1em";
           secondDiv.append(totalPrice)
           showDiv.append(firstDiv);
           showDiv.append(secondDiv);
           quantity.append(showDiv);
           counterIndex+=1;
          counter.textContent = counterIndex;
          sumTotal.push(totalPrice);
        })
    })
}
let pay = document.getElementById("Pay");
pay.addEventListener("click",()=>{
    addUp();
    sumTotal=[];
    popUp()
})
function addUp (){
     totalPrice = 0;
     for(i=0;i<sumTotal.length; i++){
                initial += sumTotal[i];
        }
         console.log(initial)
}
displayBtn()

// This Function Turns on and Off the Cartitems
function imgDisplay(){
    imageContainer.addEventListener("click",()=>{
    cartItem.classList.toggle("display")
    console.log("clicked")
})
}
imgDisplay()
function popUp(){
    let popUpContainer = document.createElement("div")
    popUpContainer.classList.add("popUpContainer");
    let popUpBtn = document.createElement("button");
    popUpBtn.textContent = "CLOSE";
    popUpContainer.append(popUpBtn);
    popUpBtn.classList.add("popUpBtn");
    let popUpTag = document.createElement("h3");
    popUpTag.textContent = "THANK YOU FOR SHOPPING WITH US";
    popUpTag.classList.add("popUpTag")
    popUpContainer.append(popUpTag);
    let totalPopUp = document.createElement("h3");
    totalPopUp.textContent = `The Total Price is: N${initial}`
    totalPopUp.classList.add("popUpTotal");
    popUpContainer.append(totalPopUp);
    groceryContainer.append(popUpContainer);
    popUpBtn.addEventListener("click",()=>{
        popUpContainer.style.display = "none";
    })
}